
      $(document).ready(function() {
        $(".pro_box").delay(900).fadeIn(800);
        $(".black").delay(1E3).fadeIn(800);
        $(".pro_box2").delay(2500).fadeIn(800);
        $(".webbxs").delay(3500).fadeIn(800);
        $("#webgetcode").delay(4E3).fadeIn(800);
        $("#botgnws").delay(4E3).fadeIn(800)
      });